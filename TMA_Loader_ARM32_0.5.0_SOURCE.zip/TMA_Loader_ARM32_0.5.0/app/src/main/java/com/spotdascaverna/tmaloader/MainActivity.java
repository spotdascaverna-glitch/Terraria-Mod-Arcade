package com.spotdascaverna.tmaloader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 301;
    private static final int REQ_STORAGE = 302;
    private static final String SENTINEL_DIR = "TMA_Sentinel";
    private static final String MODS = "Mods";
    private static final String TEXTURES = "Texturas";
    private static final String MAPS = "Mapas";
    private final int bg = Color.rgb(8, 17, 11);
    private final int panel = Color.rgb(17, 32, 22);
    private final int green = Color.rgb(109, 229, 138);
    private final int white = Color.rgb(239, 247, 240);
    private final int muted = Color.rgb(166, 187, 171);
    private LinearLayout page;
    private String pendingCategory = MAPS;
    private File pendingMapInstall;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        installSentinelCrashHandler();
        showHome();
        showPreviousCrashNotice();
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(26), dp(20), dp(28));
        scroll.addView(page);
        TextView eyebrow = text("TMA  •  VERSÃO 0.4.0", 12, green, true);
        eyebrow.setLetterSpacing(0.12f); page.addView(eyebrow);
        TextView title = text("TERRARIA\nMOD ARCADE", 30, white, true);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        title.setPadding(0, dp(10), 0, dp(5)); page.addView(title);
        page.addView(text("Catálogo e biblioteca de conteúdo para Terraria.", 14, muted, false));
        addGap(18);
        LinearLayout hero = card(); page.addView(hero, matchWrap());
        hero.addView(text("CENTRAL TMA", 11, green, true));
        TextView ht = text("Explore. Organize. Preserve.", 19, white, true);
        ht.setPadding(0, dp(6), 0, dp(5)); hero.addView(ht);
        hero.addView(text("A versão 0.4.0 separa Mods, Texturas e Mapas. A compatibilidade é indicada em cada seção para não prometer instalações que o Terraria Mobile não oferece oficialmente.", 13, muted, false));
        addGap(18); page.addView(sectionLabel("CATÁLOGO"));
        addCategoryButton("⚔  MODS", MODS);
        addCategoryButton("✦  TEXTURAS", TEXTURES);
        addCategoryButton("▣  MAPAS", MAPS);
        addGap(18); page.addView(sectionLabel("FERRAMENTAS"));
        Button diag = actionButton("Diagnóstico do aparelho"); page.addView(diag, buttonParams()); diag.setOnClickListener(v -> showDiagnostics());
        Button sentinel = actionButton("🛡  Sentinela TMA — verificar integridade"); page.addView(sentinel, buttonParams()); sentinel.setOnClickListener(v -> runSentinelCheck());
        Button all = actionButton("Ver toda a biblioteca"); page.addView(all, buttonParams()); all.setOnClickListener(v -> showAllLibrary());
        addGap(18);
        LinearLayout note = card(); page.addView(note, matchWrap());
        note.addView(text("SEGURANÇA", 11, green, true));
        note.addView(text("O TMA não executa arquivos baixados. Faça backup dos mundos antes de substituir arquivos e feche o Terraria antes de copiar um mapa.", 12, muted, false));
        TextView foot = text("TERRARIA MOD ARCADE  •  ANDROID", 11, muted, false); foot.setGravity(Gravity.CENTER); foot.setPadding(0, dp(22), 0, 0); page.addView(foot);
        setContentView(scroll);
    }

    private void addCategoryButton(String label, String category) {
        Button b = actionButton(label + "   ›"); page.addView(b, buttonParams());
        b.setOnClickListener(v -> showCategory(category));
    }

    private void showCategory(String category) {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(20), dp(22), dp(20), dp(28)); scroll.addView(page);
        Button back = actionButton("‹  Voltar"); page.addView(back, buttonParams()); back.setOnClickListener(v -> showHome());
        addGap(14); page.addView(sectionLabel("CATÁLOGO / " + category.toUpperCase()));
        TextView title = text(category, 28, white, true); title.setPadding(0, 0, 0, dp(6)); page.addView(title);
        if (MODS.equals(category)) {
            addInfoCard("Compatibilidade mobile", "A 505 Games informa que mods não são suportados oficialmente nas plataformas móveis. Esta seção é um catálogo informativo; não há instalação de mods no Terraria Mobile pelo TMA.", "NÃO SUPORTADO OFICIALMENTE");
            addInfoCard("Calamity Mod", "Projeto de conteúdo para Terraria de PC com tModLoader. Não é compatível com a instalação mobile padrão.", "PC / tMODLOADER");
            addInfoCard("Thorium Mod", "Projeto de conteúdo para Terraria de PC com tModLoader. Não é um pacote instalável pelo TMA Mobile.", "PC / tMODLOADER");
            addInfoCard("Sua biblioteca de mods", "Você pode guardar arquivos de mod para organização e consulta. Guardar um arquivo não o torna executável no Terraria Mobile.", "ARMAZENAMENTO LOCAL");
        } else if (TEXTURES.equals(category)) {
            addInfoCard("Compatibilidade mobile", "A 505 Games informa que pacotes de textura também não são suportados oficialmente nas plataformas móveis. O TMA não substitui sprites ou arquivos do jogo.", "NÃO SUPORTADO OFICIALMENTE");
            addInfoCard("Pacotes de recursos", "Resource Packs oficiais são um recurso documentado para as versões desktop. Arquivos desse tipo podem ser guardados aqui, mas não serão ativados no Terraria Mobile.", "DESKTOP");
            addInfoCard("Biblioteca de texturas", "Importe arquivos de imagem ou pacotes para manter tudo organizado no TMA. A importação não altera o jogo.", "ARMAZENAMENTO LOCAL");
        } else {
            addInfoCard("Mundos do Terraria", "Mundos são arquivos .wld. No Android, a pasta Worlds costuma ficar em Android/data/com.and.games505.TerrariaPaid/Worlds. O acesso pode variar conforme o sistema e o gerenciador de arquivos.", "IMPORTAÇÃO DE .WLD");
            addInfoCard("Instalação de mapas", "O TMA pode tentar copiar um arquivo .wld para a pasta Worlds do Terraria. Feche o jogo, mantenha backup e confirme que o mapa é da mesma versão do Terraria.", "ANDROID 10 • TESTE NECESSÁRIO");
        }
        addGap(12);
        Button imp = actionButton("＋  Importar arquivo de " + category.toLowerCase()); page.addView(imp, buttonParams()); imp.setOnClickListener(v -> chooseFile(category));
        Button lib = actionButton("Ver minha biblioteca de " + category.toLowerCase()); page.addView(lib, buttonParams()); lib.setOnClickListener(v -> showLibrary(category));
        if (MAPS.equals(category)) {
            Button help = actionButton("Onde ficam os mundos no Android?"); page.addView(help, buttonParams());
            help.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Pasta Worlds").setMessage("Caminho normalmente usado pelo Terraria Android:\n\nArmazenamento interno/Android/data/com.and.games505.TerrariaPaid/Worlds\n\nNo Android 10, o acesso pode depender da permissão e do gerenciador de arquivos. O TMA tentará copiar o .wld para essa pasta. Faça backup antes.").setPositiveButton("OK", null).show());
        }
        setContentView(scroll);
    }

    private void addInfoCard(String title, String body, String tag) {
        addGap(9); LinearLayout c = card(); page.addView(c, matchWrap());
        c.addView(text(tag, 10, green, true));
        TextView t = text(title, 17, white, true); t.setPadding(0, dp(5), 0, dp(4)); c.addView(t);
        c.addView(text(body, 12, muted, false));
    }

    private void chooseFile(String category) {
        pendingCategory = category;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_FILE); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível abrir os arquivos.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); String name = safeName(getDisplayName(uri));
        if (MAPS.equals(pendingCategory) && !name.toLowerCase().endsWith(".wld")) {
            new AlertDialog.Builder(this).setTitle("Formato de mapa não reconhecido").setMessage("Para a seção Mapas, selecione um mundo do Terraria com extensão .wld. O TMA não aceita .zip ou .twld como mundo principal.").setPositiveButton("OK", null).show(); return;
        }
        try {
            File folder = getCategoryFolder(pendingCategory); File dest = uniqueFile(folder, name);
            try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(dest)) {
                if (in == null) throw new IllegalStateException("Não foi possível ler o arquivo.");
                byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            }
            Toast.makeText(this, "Arquivo guardado em " + pendingCategory + "!", Toast.LENGTH_LONG).show();
            if (MAPS.equals(pendingCategory)) {
                new AlertDialog.Builder(this).setTitle("Mapa importado").setMessage("O arquivo foi guardado no TMA. Quer tentar copiá-lo para a pasta Worlds do Terraria agora? Feche o Terraria antes.")
                    .setPositiveButton("Copiar para Terraria", (d,w) -> installWorld(dest))
                    .setNegativeButton("Só guardar", (d,w) -> showCategory(MAPS)).show();
            } else {
                new AlertDialog.Builder(this).setTitle("Importação concluída").setMessage("O arquivo foi guardado na biblioteca do TMA. Ele não foi instalado nem executado no Terraria Mobile.").setPositiveButton("OK", (d,w) -> showCategory(pendingCategory)).show();
            }
        } catch (Exception e) { Toast.makeText(this, "Falha ao importar: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void installWorld(File source) {
        if (!source.getName().toLowerCase().endsWith(".wld")) { Toast.makeText(this, "Somente arquivos .wld podem ser copiados como mundo.", Toast.LENGTH_LONG).show(); return; }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingMapInstall = source; requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE); return;
        }
        copyWorldToGame(source);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE && pendingMapInstall != null) {
            File file = pendingMapInstall; pendingMapInstall = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) copyWorldToGame(file);
            else new AlertDialog.Builder(this).setTitle("Permissão necessária").setMessage("Sem permissão de armazenamento, o TMA não consegue copiar o mundo para a pasta do Terraria. O arquivo continua guardado na biblioteca do TMA.").setPositiveButton("OK", null).show();
        }
    }

    private void copyWorldToGame(File source) {
        try {
            File worlds = new File(Environment.getExternalStorageDirectory(), "Android/data/com.and.games505.TerrariaPaid/Worlds");
            if (!worlds.exists() && !worlds.mkdirs()) throw new IllegalStateException("Não foi possível criar a pasta Worlds.");
            File dest = new File(worlds, source.getName());
            if (dest.exists()) {
                new AlertDialog.Builder(this).setTitle("O mundo já existe").setMessage("Já existe um arquivo com esse nome. Deseja substituir? Faça backup antes.")
                    .setPositiveButton("Substituir", (d,w) -> copyFileNow(source, dest))
                    .setNegativeButton("Cancelar", null).show();
            } else copyFileNow(source, dest);
        } catch (Exception e) { new AlertDialog.Builder(this).setTitle("Não foi possível copiar").setMessage(e.getMessage() + "\n\nO arquivo continua guardado na biblioteca TMA. Você pode tentar copiar manualmente com o gerenciador de arquivos.").setPositiveButton("OK", null).show(); }
    }

    private void copyFileNow(File source, File dest) {
        try (InputStream in = new FileInputStream(source); FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            new AlertDialog.Builder(this).setTitle("Cópia concluída").setMessage("O mundo foi copiado para:\n" + dest.getAbsolutePath() + "\n\nAbra o Terraria e confira se aparece na lista. A compatibilidade do mundo não é garantida. Mantenha o backup original.").setPositiveButton("OK", (d,w) -> showCategory(MAPS)).show();
        } catch (Exception e) { new AlertDialog.Builder(this).setTitle("Falha ao copiar mundo").setMessage(e.getMessage() + "\nO arquivo original continua guardado no TMA.").setPositiveButton("OK", null).show(); }
    }

    private void showLibrary(String category) { showLibraryFiles(category, getCategoryFiles(category)); }
    private void showAllLibrary() {
        ArrayList<File> all = new ArrayList<>(); all.addAll(getCategoryFiles(MODS)); all.addAll(getCategoryFiles(TEXTURES)); all.addAll(getCategoryFiles(MAPS));
        showLibraryFiles("Toda a biblioteca", all);
    }
    private void showLibraryFiles(String title, ArrayList<File> files) {
        if (files.isEmpty()) { new AlertDialog.Builder(this).setTitle(title).setMessage("Ainda não há arquivos nesta seção. Abra uma categoria e toque em Importar arquivo.").setPositiveButton("OK", null).show(); return; }
        Collections.sort(files, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        String[] labels = new String[files.size()];
        for (int i=0;i<files.size();i++) labels[i] = files.get(i).getName() + "  •  " + formatSize(files.get(i).length());
        new AlertDialog.Builder(this).setTitle(title).setItems(labels, (d,which) -> showFileOptions(files.get(which))).setNegativeButton("Fechar", null).show();
    }
    private void showFileOptions(File file) {
        String category = file.getParentFile().getName();
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(file.getName()).setMessage("Categoria: " + category + "\nTamanho: " + formatSize(file.length()) + "\n\nArquivo guardado no espaço privado do TMA.");
        if (MAPS.equals(category) && file.getName().toLowerCase().endsWith(".wld")) b.setNeutralButton("Copiar para Terraria", (d,w) -> installWorld(file));
        b.setPositiveButton("Excluir", (d,w) -> { if (file.delete()) Toast.makeText(this, "Arquivo excluído.", Toast.LENGTH_SHORT).show(); else Toast.makeText(this, "Não foi possível excluir.", Toast.LENGTH_LONG).show(); });
        b.setNegativeButton("Voltar", null); b.show();
    }

    private File getCategoryFolder(String category) {
        File root = new File(getFilesDir(), "TMA_Library"); File folder = new File(root, category);
        if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Não foi possível criar a biblioteca."); return folder;
    }
    private ArrayList<File> getCategoryFiles(String category) {
        File[] found = getCategoryFolder(category).listFiles(); ArrayList<File> list = new ArrayList<>();
        if (found != null) for (File f : found) if (f.isFile()) list.add(f); return list;
    }
    private String getDisplayName(Uri uri) {
        String result = "arquivo_importado";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) result = c.getString(i); }
        } catch (Exception ignored) { }
        return result == null ? "arquivo_importado" : result;
    }
    private String safeName(String name) {
        String cleaned = name.replaceAll("[^a-zA-Z0-9._() -]", "_").trim();
        return cleaned.isEmpty() || cleaned.equals(".") || cleaned.equals("..") ? "arquivo_importado" : cleaned;
    }
    private File uniqueFile(File folder, String name) {
        File f = new File(folder, name); if (!f.exists()) return f;
        int dot = name.lastIndexOf('.'); String base = dot > 0 ? name.substring(0,dot) : name; String ext = dot > 0 ? name.substring(dot) : ""; int n=2;
        do { f = new File(folder, base + "_" + n++ + ext); } while (f.exists()); return f;
    }
    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B"; if (bytes < 1024*1024) return new DecimalFormat("0.0").format(bytes/1024.0)+" KB"; return new DecimalFormat("0.00").format(bytes/(1024.0*1024.0))+" MB";
    }
    // Sentinela local: registra falhas não tratadas e executa verificações sob demanda.
    // Não envia dados para a internet nem fica monitorando o celular em segundo plano.
    private File getSentinelFolder() {
        File folder = new File(getFilesDir(), SENTINEL_DIR);
        if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Não foi possível criar a pasta de diagnóstico.");
        return folder;
    }

    private File getCrashLogFile() {
        return new File(getSentinelFolder(), "ultimo_erro.txt");
    }

    private void installSentinelCrashHandler() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try (PrintWriter out = new PrintWriter(new FileWriter(getCrashLogFile(), true))) {
                out.println("Falha inesperada: " + new Date());
                out.println("Thread: " + thread.getName());
                error.printStackTrace(out);
                out.println("----------------------------------------");
            } catch (Exception ignored) { }
            if (previous != null) previous.uncaughtException(thread, error);
            else android.os.Process.killProcess(android.os.Process.myPid());
        });
    }

    private void showPreviousCrashNotice() {
        try {
            File log = getCrashLogFile();
            if (log.exists() && log.length() > 0) {
                new AlertDialog.Builder(this)
                    .setTitle("Sentinela TMA encontrou um encerramento")
                    .setMessage("O aplicativo registrou uma falha na sessão anterior. Abra “Sentinela TMA” na tela inicial para ver o diagnóstico e compartilhar o relatório.")
                    .setPositiveButton("Entendi", null)
                    .show();
            }
        } catch (Exception ignored) { }
    }

    private void runSentinelCheck() {
        StringBuilder report = new StringBuilder();
        int passed = 0;
        int total = 0;
        report.append("TMA SENTINELA — RELATÓRIO DE INTEGRIDADE\n");
        report.append("Data: ").append(new Date()).append("\n");
        report.append("Aplicativo: ").append(getPackageName()).append("\n");
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            String version = info.versionName == null ? "desconhecida" : info.versionName;
            report.append("Versão: ").append(version).append("\n");
        } catch (Exception e) {
            report.append("Versão: não foi possível ler\n");
        }
        report.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        report.append("Modelo: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n\n");

        total++;
        boolean internalWritable = getFilesDir().exists() && getFilesDir().canWrite();
        if (internalWritable) passed++;
        report.append(mark(internalWritable)).append(" Armazenamento privado do app: ").append(internalWritable ? "gravável" : "sem escrita").append("\n");

        total++;
        long free = getFilesDir().getUsableSpace();
        boolean enough = free > 2L * 1024L * 1024L;
        if (enough) passed++;
        report.append(mark(enough)).append(" Espaço livre privado: ").append(formatSize(free)).append("\n");

        String[] categories = new String[]{MODS, TEXTURES, MAPS};
        for (String category : categories) {
            total++;
            boolean ok = false;
            try {
                File folder = getCategoryFolder(category);
                File probe = new File(folder, ".sentinel_test");
                try (FileOutputStream out = new FileOutputStream(probe)) { out.write("ok".getBytes("UTF-8")); }
                ok = probe.exists() && probe.length() == 2 && probe.delete();
            } catch (Exception ignored) { }
            if (ok) passed++;
            report.append(mark(ok)).append(" Biblioteca ").append(category).append(": ").append(ok ? "leitura/escrita OK" : "falha").append("\n");
        }

        total++;
        boolean sentinelWritable = false;
        try {
            File folder = getSentinelFolder();
            File probe = new File(folder, ".sentinel_test");
            try (FileOutputStream out = new FileOutputStream(probe)) { out.write(1); }
            sentinelWritable = probe.exists() && probe.delete();
        } catch (Exception ignored) { }
        if (sentinelWritable) passed++;
        report.append(mark(sentinelWritable)).append(" Registro da Sentinela: ").append(sentinelWritable ? "OK" : "falha").append("\n");

        total++;
        boolean javaOnly = true; // O projeto não declara bibliotecas JNI/nativas no APK.
        if (javaOnly) passed++;
        report.append(mark(javaOnly)).append(" Arquitetura: app Java sem bibliotecas nativas declaradas\n");
        report.append("\nResultado: ").append(passed).append("/").append(total).append(" verificações aprovadas.\n");
        report.append("Nota: este teste verifica o próprio TMA; não consegue diagnosticar uma instalação rejeitada antes de o app abrir.\n");

        try {
            File saved = new File(getSentinelFolder(), "relatorio_integridade.txt");
            try (FileOutputStream out = new FileOutputStream(saved)) { out.write(report.toString().getBytes("UTF-8")); }
        } catch (Exception e) {
            report.append("\nNão foi possível salvar o relatório: ").append(e.getMessage());
        }

        final String finalReport = report.toString();
        new AlertDialog.Builder(this)
            .setTitle("Sentinela TMA • " + passed + "/" + total + " OK")
            .setMessage(finalReport)
            .setPositiveButton("Fechar", null)
            .setNeutralButton("Compartilhar relatório", (dialog, which) -> {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_SUBJECT, "Relatório Sentinela TMA");
                share.putExtra(Intent.EXTRA_TEXT, finalReport);
                startActivity(Intent.createChooser(share, "Compartilhar diagnóstico"));
            })
            .show();
    }

    private String mark(boolean ok) { return ok ? "[OK]" : "[FALHA]"; }

    private void showDiagnostics() {
        StringBuilder abis = new StringBuilder(); if (Build.SUPPORTED_ABIS != null) for (String abi : Build.SUPPORTED_ABIS) { if (abis.length()>0) abis.append(", "); abis.append(abi); }
        if (abis.length()==0) abis.append("Não identificada");
        String msg = "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\nFabricante: " + Build.MANUFACTURER + "\nModelo: " + Build.MODEL + "\nABIs: " + abis + "\n\nO app usa Java e não depende de bibliotecas nativas.";
        new AlertDialog.Builder(this).setTitle("Diagnóstico").setMessage(msg).setPositiveButton("OK", null).show();
    }
    private void addGap(int h) { View v = new View(this); page.addView(v, new LinearLayout.LayoutParams(1,dp(h))); }
    private LinearLayout card() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(15),dp(15),dp(15),dp(15)); l.setBackground(round(panel,dp(16),Color.rgb(35,62,43))); return l; }
    private TextView sectionLabel(String s) { TextView t=text(s,11,green,true); t.setPadding(0,0,0,dp(6)); return t; }
    private Button actionButton(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(white); b.setTextSize(14); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setGravity(Gravity.CENTER); b.setBackground(round(Color.rgb(25,54,35),dp(13),Color.rgb(65,119,78))); b.setPadding(dp(12),dp(8),dp(12),dp(8)); return b; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private GradientDrawable round(int color,int radius,int stroke) { GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); g.setStroke(dp(1),stroke); return g; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1,-2); }
    private LinearLayout.LayoutParams buttonParams() { LinearLayout.LayoutParams p=matchWrap(); p.topMargin=dp(7); return p; }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
