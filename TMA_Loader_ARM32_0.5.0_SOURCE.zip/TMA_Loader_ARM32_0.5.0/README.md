# Terraria Mod Arcade — TMA Loader 0.5.0

## Novidades
- Sentinela local para verificar o armazenamento privado e as bibliotecas Mods, Texturas e Mapas.
- Registro local de exceções não tratadas para ajudar a investigar encerramentos inesperados.
- Relatório de integridade que pode ser compartilhado manualmente pelo usuário.
- Nenhum dado é enviado automaticamente para servidores.
- Mantém o catálogo informativo e a biblioteca local.

## Limitações
- A Sentinela só consegue verificar o aplicativo depois que ele abre. Ela não consegue descobrir por que o Android rejeita um APK antes da instalação.
- Mods e pacotes de textura não são ativados no Terraria Mobile.
- A cópia de mundos depende das permissões e restrições de armazenamento do Android.

## Compilação
Requer JDK 17, Android SDK Platform 35 e Gradle 8.7.
Execute `gradle assembleDebug`.
