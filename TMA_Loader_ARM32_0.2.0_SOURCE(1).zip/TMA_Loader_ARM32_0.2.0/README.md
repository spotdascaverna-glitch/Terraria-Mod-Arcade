# TMA Loader Android 0.3.0

Projeto Android nativo em Java, sem dependências externas de bibliotecas de terceiros.

## Recursos desta versão
- Interface verde escura TMA, versão 0.3.0.
- Diagnóstico local do Android, modelo e ABIs.
- Biblioteca privada local: importar, listar e excluir arquivos selecionados pelo usuário.
- Os arquivos importados não são executados, extraídos nem enviados à internet.
- O aplicativo não altera arquivos do Terraria e não instala mods dentro do jogo.

## Compatibilidade do aplicativo
- `minSdk 23`: Android 6.0 ou superior.
- `targetSdk 28`.
- Código Java sem bibliotecas nativas; o APK pode ser instalado em Android ARM de 32 bits e 64 bits, desde que a versão Android seja compatível.
- `versionCode 3`, `versionName 0.3.0`.

## Compilação
Com Android SDK e Gradle disponíveis, execute `gradle assembleDebug` na raiz do projeto. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

**Limite técnico:** ainda não existe carregador validado para Terraria Mobile 1.4.5.8.1. A biblioteca do TMA é apenas armazenamento local nesta versão.
