package com.spotdascaverna.tmaloader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 301;
    private final int bg = Color.rgb(8, 17, 11);
    private final int panel = Color.rgb(17, 32, 22);
    private final int green = Color.rgb(109, 229, 138);
    private final int white = Color.rgb(239, 247, 240);
    private final int muted = Color.rgb(166, 187, 171);
    private LinearLayout page;
    private TextView librarySummary;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildScreen();
        refreshLibrarySummary();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(26), dp(20), dp(28));
        scroll.addView(page);

        TextView eyebrow = text("TMA  •  VERSÃO 0.3.0", 12, green, true);
        eyebrow.setLetterSpacing(0.12f);
        page.addView(eyebrow);

        TextView title = text("TERRARIA\nMOD ARCADE", 30, white, true);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        title.setPadding(0, dp(10), 0, dp(5));
        page.addView(title);
        page.addView(text("Sua central móvel para organizar conteúdo de Terraria.", 14, muted, false));

        addGap(20);
        LinearLayout status = card();
        page.addView(status, matchWrap());
        status.addView(text("STATUS DO PROJETO", 11, green, true));
        TextView statusTitle = text("Biblioteca local disponível", 19, white, true);
        statusTitle.setPadding(0, dp(7), 0, dp(5));
        status.addView(statusTitle);
        status.addView(text("Importe e organize arquivos no espaço privado do TMA. Esta versão não injeta código nem instala conteúdo dentro do Terraria.", 13, muted, false));

        addGap(18);
        page.addView(sectionLabel("BIBLIOTECA"));
        librarySummary = text("Carregando biblioteca…", 13, muted, false);
        librarySummary.setPadding(0, 0, 0, dp(8));
        page.addView(librarySummary);

        Button importButton = actionButton("＋  Importar arquivo");
        page.addView(importButton, buttonParams());
        importButton.setOnClickListener(v -> chooseFile());

        Button libraryButton = actionButton("Ver arquivos guardados");
        page.addView(libraryButton, buttonParams());
        libraryButton.setOnClickListener(v -> showLibrary());

        addGap(18);
        page.addView(sectionLabel("FERRAMENTAS"));
        Button diagnostic = actionButton("Diagnóstico do aparelho");
        page.addView(diagnostic, buttonParams());
        diagnostic.setOnClickListener(v -> showDiagnostics());

        Button compatibility = actionButton("Compatibilidade e limites");
        page.addView(compatibility, buttonParams());
        compatibility.setOnClickListener(v -> showCompatibility());

        addGap(18);
        LinearLayout note = card();
        page.addView(note, matchWrap());
        note.addView(text("IMPORTANTE", 11, green, true));
        TextView noteText = text("Arquivos importados ficam guardados dentro do TMA. Não são extraídos, executados ou enviados para a internet. Faça cópias de segurança dos seus mundos e personagens antes de testar qualquer modificação externa.", 12, muted, false);
        noteText.setPadding(0, dp(7), 0, 0);
        note.addView(noteText);

        TextView footer = text("TERRARIA MOD ARCADE  •  ANDROID\nProjeto independente", 11, muted, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, dp(6));
        page.addView(footer);
        setContentView(scroll);
    }

    private void chooseFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(intent, PICK_FILE);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = getDisplayName(uri);
        try {
            File folder = getLibraryFolder();
            File destination = uniqueFile(folder, safeName(name));
            try (InputStream input = getContentResolver().openInputStream(uri);
                 FileOutputStream output = new FileOutputStream(destination)) {
                if (input == null) throw new IllegalStateException("Arquivo não pôde ser lido.");
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            }
            Toast.makeText(this, "Arquivo guardado na biblioteca!", Toast.LENGTH_LONG).show();
            refreshLibrarySummary();
            showFileSaved(destination);
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao importar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "arquivo_importado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) { }
        return result == null ? "arquivo_importado" : result;
    }

    private String safeName(String name) {
        String cleaned = name.replaceAll("[^a-zA-Z0-9._() -]", "_").trim();
        if (cleaned.isEmpty() || cleaned.equals(".") || cleaned.equals("..")) return "arquivo_importado";
        return cleaned;
    }

    private File uniqueFile(File folder, String name) {
        File file = new File(folder, name);
        if (!file.exists()) return file;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        int n = 2;
        do { file = new File(folder, base + "_" + n++ + ext); } while (file.exists());
        return file;
    }

    private File getLibraryFolder() {
        File folder = new File(getFilesDir(), "TMA_Library");
        if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Não foi possível criar a biblioteca.");
        return folder;
    }

    private ArrayList<File> getLibraryFiles() {
        File[] files = getLibraryFolder().listFiles();
        ArrayList<File> result = new ArrayList<>();
        if (files != null) {
            for (File file : files) if (file.isFile()) result.add(file);
        }
        return result;
    }

    private void refreshLibrarySummary() {
        if (librarySummary == null) return;
        int count = getLibraryFiles().size();
        librarySummary.setText(count == 1 ? "1 arquivo guardado neste aparelho." : count + " arquivos guardados neste aparelho.");
    }

    private void showFileSaved(File file) {
        new AlertDialog.Builder(this)
                .setTitle("Importação concluída")
                .setMessage(file.getName() + "\n\nO arquivo foi guardado dentro do TMA. Ele ainda não foi instalado no Terraria.")
                .setPositiveButton("OK", null).show();
    }

    private void showLibrary() {
        ArrayList<File> files = getLibraryFiles();
        if (files.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Biblioteca TMA")
                    .setMessage("Sua biblioteca está vazia. Use Importar arquivo para guardar um arquivo neste aparelho.")
                    .setPositiveButton("Entendi", null).show();
            return;
        }
        String[] names = new String[files.size()];
        for (int i = 0; i < files.size(); i++) names[i] = files.get(i).getName() + "  •  " + formatSize(files.get(i).length());
        new AlertDialog.Builder(this).setTitle("Arquivos guardados")
                .setItems(names, (dialog, which) -> showFileOptions(files.get(which)))
                .setNegativeButton("Fechar", null).show();
    }

    private void showFileOptions(File file) {
        new AlertDialog.Builder(this).setTitle(file.getName())
                .setMessage("Tamanho: " + formatSize(file.length()) + "\nLocal: biblioteca privada do TMA")
                .setPositiveButton("Excluir da biblioteca", (d, w) -> {
                    if (file.delete()) Toast.makeText(this, "Arquivo excluído.", Toast.LENGTH_SHORT).show();
                    else Toast.makeText(this, "Não foi possível excluir o arquivo.", Toast.LENGTH_LONG).show();
                    refreshLibrarySummary();
                })
                .setNegativeButton("Voltar", null).show();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return new DecimalFormat("0.0").format(bytes / 1024.0) + " KB";
        return new DecimalFormat("0.00").format(bytes / (1024.0 * 1024.0)) + " MB";
    }

    private void showDiagnostics() {
        StringBuilder abis = new StringBuilder();
        if (Build.SUPPORTED_ABIS != null) {
            for (String abi : Build.SUPPORTED_ABIS) {
                if (abis.length() > 0) abis.append(", ");
                abis.append(abi);
            }
        }
        if (abis.length() == 0) abis.append("Não identificada");
        String message = "Android: " + Build.VERSION.RELEASE
                + " (API " + Build.VERSION.SDK_INT + ")\n"
                + "Fabricante: " + Build.MANUFACTURER + "\n"
                + "Modelo: " + Build.MODEL + "\n"
                + "ABIs informadas: " + abis + "\n\n"
                + "O TMA não inclui bibliotecas nativas nesta versão. O diagnóstico não comprova compatibilidade de mods.";
        new AlertDialog.Builder(this).setTitle("Diagnóstico do aparelho")
                .setMessage(message).setPositiveButton("OK", null).show();
    }

    private void showCompatibility() {
        new AlertDialog.Builder(this).setTitle("Compatibilidade")
                .setMessage("Aplicativo TMA: Android 6.0 ou superior.\n\nTerraria Mobile 1.4.5.8.1: integração de mods ainda não implementada nem validada.\n\nA biblioteca apenas guarda arquivos no espaço privado do aplicativo. Ela não modifica o Terraria, não injeta código e não ativa mods.")
                .setPositiveButton("Entendi", null).show();
    }

    private void addGap(int height) {
        View gap = new View(this);
        page.addView(gap, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(15), dp(15), dp(15));
        box.setBackground(round(panel, dp(16), Color.rgb(35, 62, 43)));
        return box;
    }

    private TextView sectionLabel(String value) {
        TextView view = text(value, 11, green, true);
        view.setPadding(0, 0, 0, dp(6));
        return view;
    }

    private Button actionButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(white);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setBackground(round(Color.rgb(25, 54, 35), dp(13), Color.rgb(65, 119, 78)));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        return button;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(radius);
        shape.setStroke(dp(1), stroke);
        return shape;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(7);
        return params;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
