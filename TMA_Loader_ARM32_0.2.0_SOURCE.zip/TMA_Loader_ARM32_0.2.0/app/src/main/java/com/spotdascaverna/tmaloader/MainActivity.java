package com.spotdascaverna.tmaloader;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 17, 11);
    private final int panel = Color.rgb(17, 32, 22);
    private final int green = Color.rgb(109, 229, 138);
    private final int white = Color.rgb(239, 247, 240);
    private final int muted = Color.rgb(166, 187, 171);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(page);

        TextView eyebrow = text("TMA  •  VERSÃO 0.2.0", 12, green, true);
        eyebrow.setLetterSpacing(0.12f);
        page.addView(eyebrow);

        TextView title = text("TERRARIA\nMOD ARCADE", 31, white, true);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        title.setPadding(0, dp(12), 0, dp(6));
        page.addView(title);

        page.addView(text("Sua central móvel de conteúdo para Terraria.", 15, muted, false));

        View gap = new View(this);
        page.addView(gap, new LinearLayout.LayoutParams(1, dp(24)));

        LinearLayout statusCard = card();
        page.addView(statusCard, matchWrap());
        statusCard.addView(text("STATUS DO PROJETO", 12, green, true));
        TextView status = text("Aplicativo inicializado", 20, white, true);
        status.setPadding(0, dp(8), 0, dp(5));
        statusCard.addView(status);
        statusCard.addView(text(
                "A interface está funcionando. A integração de carregamento de mods ainda não foi implementada nem validada para Terraria Mobile 1.4.5.8.1.",
                14, muted, false));

        View gap2 = new View(this);
        page.addView(gap2, new LinearLayout.LayoutParams(1, dp(18)));

        page.addView(sectionLabel("FERRAMENTAS"));

        Button diagnostic = actionButton("Diagnóstico do aparelho");
        page.addView(diagnostic, buttonParams());
        diagnostic.setOnClickListener(v -> showDiagnostics());

        Button library = actionButton("Abrir biblioteca");
        page.addView(library, buttonParams());
        library.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Biblioteca TMA")
                .setMessage("A biblioteca de mods, texturas e mapas está em desenvolvimento. Esta versão ainda não instala nem altera arquivos do Terraria.")
                .setPositiveButton("Entendi", null)
                .show());

        Button loader = actionButton("Estado do carregador");
        page.addView(loader, buttonParams());
        loader.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Carregador de mods")
                .setMessage("Nenhum mecanismo de carregamento foi ativado nesta versão. Primeiro precisamos confirmar um método compatível para a versão exata do Terraria.")
                .setPositiveButton("Fechar", null)
                .show());

        View gap3 = new View(this);
        page.addView(gap3, new LinearLayout.LayoutParams(1, dp(20)));
        page.addView(sectionLabel("COMPATIBILIDADE DO APLICATIVO"));

        LinearLayout compatibility = card();
        LinearLayout.LayoutParams cp = matchWrap();
        cp.topMargin = dp(9);
        page.addView(compatibility, cp);
        compatibility.addView(infoLine("Android mínimo", "6.0 (API 23)"));
        compatibility.addView(infoLine("Android do aparelho",
                Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"));
        compatibility.addView(infoLine("Arquitetura reportada", getAbi()));

        TextView footer = text(
                "Feito para o projeto Terraria Mod Arcade.\nNenhum arquivo do jogo é modificado por esta versão.",
                12, muted, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(25), 0, dp(8));
        page.addView(footer);

        setContentView(scroll);
    }

    private void showDiagnostics() {
        String message = "Versão do Android: " + Build.VERSION.RELEASE
                + "\nAPI: " + Build.VERSION.SDK_INT
                + "\nModelo: " + Build.MANUFACTURER + " " + Build.MODEL
                + "\nArquiteturas: " + getAbi()
                + "\n\nEste diagnóstico descreve o aparelho; não confirma compatibilidade de mods.";
        new AlertDialog.Builder(this)
                .setTitle("Diagnóstico do aparelho")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private String getAbi() {
        if (Build.SUPPORTED_ABIS == null || Build.SUPPORTED_ABIS.length == 0) {
            return "Não identificada";
        }
        StringBuilder result = new StringBuilder();
        for (String abi : Build.SUPPORTED_ABIS) {
            if (result.length() > 0) result.append(", ");
            result.append(abi);
        }
        return result.toString();
    }

    private LinearLayout infoLine(String label, String value) {
        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = text(label, 13, muted, false);
        TextView right = text(value, 13, white, true);
        right.setGravity(Gravity.END);
        line.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        line.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        line.setPadding(0, dp(7), 0, dp(7));
        return line;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(round(panel, dp(16), Color.rgb(35, 62, 43)));
        return box;
    }

    private TextView sectionLabel(String value) {
        TextView view = text(value, 12, green, true);
        view.setPadding(0, 0, 0, dp(8));
        return view;
    }

    private Button actionButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(white);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setBackground(round(Color.rgb(25, 54, 35), dp(13), Color.rgb(65, 119, 78)));
        button.setPadding(dp(14), dp(9), dp(14), dp(9));
        return button;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(radius);
        shape.setStroke(dp(1), stroke);
        return shape;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = matchWrap();
        p.topMargin = dp(8);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
