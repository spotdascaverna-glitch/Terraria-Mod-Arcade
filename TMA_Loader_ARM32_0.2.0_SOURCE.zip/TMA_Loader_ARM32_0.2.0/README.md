# TMA Loader Android 0.2.0

Projeto Android nativo, sem dependências externas de bibliotecas de terceiros.

- `minSdk 23`: Android 6.0 ou superior.
- `targetSdk 28`.
- Interface própria com tema verde escuro.
- Diagnóstico local de versão do Android, modelo e ABIs.
- Não injeta código no Terraria, não altera arquivos do jogo e não instala mods nesta versão.

Para compilar: `gradle assembleDebug` a partir desta pasta.
