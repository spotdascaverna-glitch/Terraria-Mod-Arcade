# Terraria Mod Arcade 0.4.0

Aplicativo Android de catálogo e organização de referências para Terraria.

## Novidades 0.4.0
- Navegação separada: Mods, Texturas, Mapas, Biblioteca e Compatibilidade.
- Pesquisa em cada seção.
- Favoritos locais preservados.
- Fontes externas identificadas e avisos de compatibilidade.
- Referências para Bunny Loader, TManager, TerraMap Online e um mapa comunitário antigo.

## Limitações importantes
Este aplicativo é um catálogo de referências. Ele **não baixa, instala nem executa** mods, pacotes de textura ou mapas.
O Terraria Mobile oficial não oferece suporte nativo a mods ou pacotes de textura personalizados. Bunny Loader é um projeto comunitário independente; confira seus requisitos e a compatibilidade de cada pacote na documentação oficial.
Mapas comunitários podem ser antigos ou incompatíveis com versões atuais. Faça backup dos mundos antes de importar qualquer arquivo.
Itens de PC estão identificados como referências de PC, não como compatíveis com Android.

Versão Android: 0.4.0
