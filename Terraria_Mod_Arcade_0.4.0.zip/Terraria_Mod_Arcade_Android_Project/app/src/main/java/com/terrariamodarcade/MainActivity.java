package com.terrariamodarcade;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.*;
import android.text.TextWatcher;
import android.text.Editable;
import android.app.AlertDialog;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout content;
    private final int cyan = Color.rgb(83,220,220), background = Color.rgb(13,18,31),
        panel = Color.rgb(27,36,55), white = Color.rgb(239,245,255);
    private SharedPreferences prefs;
    private String searchText = "";
    private String currentPage = "Início";

    // Nome, categoria, descrição, compatibilidade, situação, fonte
    private final String[][] items = {
        {"Bunny Loader", "Ferramenta",
         "Carregador comunitário para Terraria no Android. O catálogo próprio do Bunny Loader reúne mods e pacotes de textura. É um projeto separado do Terraria Mod Arcade.",
         "Android • requer Terraria da Google Play; compatibilidade depende da versão do jogo e de cada pacote.",
         "Projeto comunitário • conferir requisitos", "https://github.com/JonataOliveiraa/Bunny-Loader"},
        {"Calamity Mod", "Mod de PC",
         "Grande expansão conhecida por novos chefes, itens e progressão. É conteúdo do ecossistema tModLoader para PC.",
         "PC • não instalar diretamente no Terraria Mobile.", "PC • referência", "https://terraria.wiki.gg/wiki/Calamity_Mod"},
        {"Thorium Mod", "Mod de PC",
         "Expansão de conteúdo do ecossistema tModLoader para PC.",
         "PC • não instalar diretamente no Terraria Mobile.", "PC • referência", "https://terraria.wiki.gg/wiki/Thorium_Mod"},
        {"Recipe Browser", "Mod de PC",
         "Ferramenta de consulta de receitas para o ecossistema tModLoader.",
         "PC • não instalar diretamente no Terraria Mobile.", "PC • referência", "https://github.com/tModLoader/tModLoader"},
        {"Boss Checklist", "Mod de PC",
         "Ferramenta de acompanhamento da progressão de chefes para tModLoader.",
         "PC • não instalar diretamente no Terraria Mobile.", "PC • referência", "https://github.com/tModLoader/tModLoader"},
        {"Catálogo de mods Android", "Mods Mobile",
         "Acesse o catálogo mantido pelo projeto Bunny Loader. Os pacotes e suas versões são publicados pelos respectivos autores; confira os requisitos antes de instalar.",
         "Android • compatibilidade varia por mod e versão do Terraria.", "Catálogo externo • conferir cada mod", "https://github.com/JonataOliveiraa/Bunny-Loader"},
        {"Pacotes de textura Bunny Loader", "Texturas",
         "O Bunny Loader documenta suporte a pacotes de textura e fontes. O Terraria Mobile oficial, sem ferramenta comunitária, não oferece instalação oficial de pacotes personalizados.",
         "Android • usar apenas pacotes indicados como compatíveis com sua versão do Bunny Loader e Terraria.", "Requer ferramenta comunitária", "https://github.com/JonataOliveiraa/Bunny-Loader"},
        {"Texturas para Terraria (PC)", "Texturas",
         "Referência de pacotes de recursos do Terraria para PC. Não presumir compatibilidade com a edição Mobile.",
         "PC • recurso nativo de PC; Mobile não oferece suporte oficial.", "PC • não compatível diretamente", "https://terrariapackcreator.com/guides/how-to-install-terraria-texture-packs"},
        {"TManager — mundos e jogadores", "Mapas",
         "Aplicativo comunitário para descobrir, baixar e importar mundos e personagens de Terraria Mobile. Também oferece visualizador e analisador de mundos.",
         "Android • confira a versão suportada na página oficial e faça cópia de segurança dos seus mundos.", "Ferramenta externa • verificar versão", "https://www.jbro129.com/tm/"},
        {"World of Light — All Items", "Mapas",
         "Mapa de itens para Terraria Mobile publicado no CurseForge. A publicação é antiga (2020), portanto a compatibilidade com Terraria 1.4.5.8.1 não está confirmada.",
         "Mobile • arquivo antigo; testar somente após fazer backup do mundo e confirmar compatibilidade.", "Compatibilidade atual não confirmada", "https://www.curseforge.com/terraria/maps/the-1-4-mobile-all-item-map-world-of-light"},
        {"TerraMap Online", "Mapas",
         "Visualizador de mapas de mundos existentes. Não é um pacote de mundo para instalar; serve para analisar um arquivo de mundo que você já possui.",
         "Navegador • compatibilidade depende do arquivo de mundo.", "Visualizador • não instala mapas", "https://terramap.github.io/"},
        {"TEdit", "Mapas",
         "Editor e visualizador de mundos para computador. Incluído apenas como referência, não como ferramenta Android.",
         "Windows • não é aplicativo Android.", "PC • referência", "https://github.com/TEdit/Terraria-Map-Editor"}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("arcade_library", MODE_PRIVATE);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        buildShell();
        showPage("Início");
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background);
        root.setPadding(dp(14),dp(14),dp(14),dp(8));
        TextView title = new TextView(this);
        title.setText("TERRARIA MOD ARCADE");
        title.setTextColor(cyan); title.setTextSize(21);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Mods • Texturas • Mapas  |  Versão 0.4.0");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(12);
        subtitle.setPadding(0,dp(4),0,dp(10)); root.addView(subtitle);

        HorizontalScrollView navScroll = new HorizontalScrollView(this);
        navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names={"Início","Mods","Texturas","Mapas","Biblioteca","Compatibilidade"};
        for(String name:names) {
            Button b=button(name); b.setTextSize(10);
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,dp(44));
            bp.rightMargin=dp(5); tabs.addView(b,bp);
            b.setOnClickListener(v->showPage(name));
        }
        navScroll.addView(tabs); root.addView(navScroll);
        ScrollView scroll=new ScrollView(this);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0,dp(10),0,dp(8)); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void showPage(String page) {
        currentPage=page; searchText=""; content.removeAllViews();
        if("Início".equals(page)) {
            heading("Bem-vindo ao Arcade 0.4.0!");
            card("Três áreas de conteúdo","Agora o catálogo está separado em Mods, Pacotes de Textura e Mapas.");
            card("Biblioteca","Salve referências nos favoritos. Eles continuam guardados neste aparelho.");
            card("Importante","O Arcade é um catálogo de referências: nesta versão ele não baixa, instala nem executa mods, texturas ou mapas. Os botões abrem as páginas dos projetos.");
            Button b=button("Explorar mods"); b.setOnClickListener(v->showPage("Mods")); content.addView(b);
            Button t=button("Ver texturas"); t.setOnClickListener(v->showPage("Texturas")); content.addView(t);
            Button m=button("Ver mapas"); m.setOnClickListener(v->showPage("Mapas")); content.addView(m);
        } else if("Compatibilidade".equals(page)) {
            heading("Compatibilidade");
            card("Terraria Mobile 1.4.5.8.1","A edição Mobile oficial não oferece suporte nativo a mods ou pacotes de textura personalizados. Ferramentas comunitárias podem acrescentar suporte, mas exigem compatibilidade específica.");
            card("Bunny Loader","Projeto comunitário Android com catálogo próprio de mods e suporte documentado a pacotes de textura. Exige Terraria da Google Play; confira a versão suportada e as instruções oficiais.");
            card("Mapas e mundos","Mundos podem ser compartilhados pela comunidade, mas mapas antigos podem não funcionar na versão atual. Faça cópia de segurança antes de importar qualquer mundo.");
            card("Aviso sobre PC","Calamity, Thorium, Recipe Browser, Boss Checklist e TEdit são referências de PC; não são instalações diretas para Terraria Mobile.");
            Button source=button("Abrir documentação do Bunny Loader");
            source.setOnClickListener(v->openUrl("https://github.com/JonataOliveiraa/Bunny-Loader")); content.addView(source);
        } else {
            heading(page);
            if("Biblioteca".equals(page)) {
                TextView note=new TextView(this); note.setText("Suas referências favoritas salvas neste aparelho.");
                note.setTextColor(Color.LTGRAY); note.setTextSize(13); note.setPadding(0,0,0,dp(8)); content.addView(note);
                renderItems(page,true);
            } else {
                EditText search=new EditText(this);
                search.setSingleLine(true);
                search.setHint("Pesquisar em "+page.toLowerCase()+"...");
                search.setTextColor(white); search.setHintTextColor(Color.LTGRAY);
                search.setPadding(dp(12),0,dp(12),0); search.setBackgroundColor(panel);
                content.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));
                LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
                content.addView(list);
                search.addTextChangedListener(new TextWatcher(){
                    public void beforeTextChanged(CharSequence s,int st,int c,int a){}
                    public void onTextChanged(CharSequence s,int st,int before,int count){
                        searchText=s.toString(); renderInto(list,page);
                    }
                    public void afterTextChanged(Editable e){}
                });
                renderInto(list,page);
            }
        }
    }

    private void renderInto(LinearLayout target,String page) {
        target.removeAllViews();
        int count=0;
        for(String[] item:items) {
            boolean match=("Mods".equals(page) && (item[1].contains("Mod") || item[1].equals("Ferramenta") || item[0].equals("Bunny Loader"))) ||
                ("Texturas".equals(page) && item[1].equals("Texturas")) ||
                ("Mapas".equals(page) && item[1].equals("Mapas"));
            String hay=(item[0]+" "+item[1]+" "+item[2]+" "+item[4]).toLowerCase();
            if(match && hay.contains(searchText.toLowerCase())) { addItemCard(target,item); count++; }
        }
        if(count==0) {
            TextView empty=new TextView(this); empty.setText("Nenhum item encontrado.");
            empty.setTextColor(Color.LTGRAY); empty.setPadding(0,dp(12),0,0); target.addView(empty);
        }
    }

    private void renderItems(String page,boolean favoritesOnly) {
        int count=0; Set<String> saved=prefs.getStringSet("favorites",new HashSet<String>());
        for(String[] item:items) if(saved.contains(item[0])) { addItemCard(content,item); count++; }
        if(count==0) {
            TextView empty=new TextView(this); empty.setText("Sua biblioteca ainda está vazia. Abra Mods, Texturas ou Mapas e favorite alguns itens.");
            empty.setTextColor(Color.LTGRAY); empty.setPadding(0,dp(12),0,0); content.addView(empty);
        }
    }

    private void addItemCard(LinearLayout target,String[] item) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel); box.setPadding(dp(13),dp(11),dp(13),dp(10));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(10); target.addView(box,p);
        TextView name=new TextView(this); name.setText(item[0]); name.setTextColor(cyan);
        name.setTextSize(16); name.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(name);
        TextView meta=new TextView(this); meta.setText(item[1]+"  •  "+item[4]);
        meta.setTextColor(Color.LTGRAY); meta.setTextSize(11); meta.setPadding(0,dp(3),0,dp(5)); box.addView(meta);
        TextView desc=new TextView(this); desc.setText(item[2]); desc.setTextColor(white);
        desc.setTextSize(12); desc.setPadding(0,0,0,dp(6)); box.addView(desc);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button details=button("Detalhes"); details.setOnClickListener(v->showDetails(item));
        Set<String> saved=prefs.getStringSet("favorites",new HashSet<String>());
        Button save=button(saved.contains(item[0])?"★ Salvo":"☆ Favoritar");
        save.setOnClickListener(v->toggleFavorite(item[0]));
        actions.addView(details,new LinearLayout.LayoutParams(0,dp(43),1));
        actions.addView(save,new LinearLayout.LayoutParams(0,dp(43),1)); box.addView(actions);
    }

    private void showDetails(String[] item) {
        new AlertDialog.Builder(this).setTitle(item[0])
            .setMessage(item[2]+"\n\nCompatibilidade:\n"+item[3]+"\n\nStatus:\n"+item[4])
            .setNeutralButton("Abrir fonte",(d,w)->openUrl(item[5]))
            .setPositiveButton("Fechar",(d,w)->{}).show();
    }

    private void toggleFavorite(String name) {
        Set<String> saved=new HashSet<>(prefs.getStringSet("favorites",new HashSet<String>()));
        if(saved.contains(name)) { saved.remove(name); Toast.makeText(this,"Removido dos favoritos",Toast.LENGTH_SHORT).show(); }
        else { saved.add(name); Toast.makeText(this,"Adicionado à Biblioteca",Toast.LENGTH_SHORT).show(); }
        prefs.edit().putStringSet("favorites",saved).apply();
        showPage(currentPage);
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); }
        catch(Exception e) { Toast.makeText(this,"Não foi possível abrir o link.",Toast.LENGTH_SHORT).show(); }
    }
    private Button button(String label) { Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setAllCaps(false); return b; }
    private void heading(String text) { TextView t=new TextView(this); t.setText(text); t.setTextColor(white); t.setTextSize(20); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(0,dp(8),0,dp(12)); content.addView(t); }
    private void card(String title,String body) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setBackgroundColor(panel); box.setPadding(dp(15),dp(13),dp(15),dp(13));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(11); content.addView(box,p);
        TextView h=new TextView(this); h.setText(title); h.setTextColor(cyan); h.setTextSize(16); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(h);
        TextView b=new TextView(this); b.setText(body); b.setTextColor(white); b.setTextSize(13); b.setLineSpacing(dp(3),1f); b.setPadding(0,dp(7),0,0); box.addView(b);
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density+0.5f); }
}
