package com.terrariamodarcade;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.text.TextWatcher;
import android.text.Editable;
import android.app.AlertDialog;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private LinearLayout content;
    private int cyan = Color.rgb(83, 220, 220);
    private int background = Color.rgb(13, 18, 31);
    private int panel = Color.rgb(27, 36, 55);
    private int white = Color.rgb(239, 245, 255);
    private SharedPreferences prefs;
    private String selectedCategory = "Todos";
    private String searchText = "";
    private final String[][] mods = {
        {"Calamity Mod", "Conteúdo", "Grande expansão de conteúdo, chefes e equipamentos. Exemplo demonstrativo; ainda não há download."},
        {"Thorium Mod", "Conteúdo", "Expansão conhecida com novas classes e conteúdo. Exemplo demonstrativo; ainda não há download."},
        {"Recipe Browser", "Utilidade", "Ferramenta para consultar receitas dentro do jogo. Exemplo demonstrativo; ainda não há download."},
        {"Boss Checklist", "Utilidade", "Ajuda a acompanhar a progressão de chefes. Exemplo demonstrativo; ainda não há download."},
        {"Pacote de texturas", "Texturas", "Categoria para futuras coleções visuais. Nenhum pacote está incluído nesta versão."}
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("arcade_library", MODE_PRIVATE);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        buildShell();
        showPage("Início");
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background);
        root.setPadding(dp(18), dp(18), dp(18), dp(12));

        TextView title = new TextView(this);
        title.setText("TERRARIA MOD ARCADE");
        title.setTextColor(cyan);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Mods para Terraria  •  Versão 0.2.0");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(14));
        root.addView(subtitle);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Início", "Catálogo", "Biblioteca"};
        for (String name : names) {
            Button b = new Button(this);
            b.setText(name);
            b.setTextSize(11);
            b.setAllCaps(false);
            b.setOnClickListener(v -> showPage(name));
            tabs.addView(b, new LinearLayout.LayoutParams(0, dp(48), 1));
        }
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(12), 0, dp(8));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void showPage(String page) {
        content.removeAllViews();
        if ("Início".equals(page)) {
            heading("Bem-vindo ao Arcade!");
            card("Catálogo organizado",
                 "Agora você pode pesquisar mods demonstrativos, filtrar por categoria e abrir os detalhes de cada item.");
            card("Biblioteca pessoal",
                 "Salve itens nos favoritos e encontre-os na aba Biblioteca. Os favoritos ficam guardados neste aparelho.");
            card("Aviso importante",
                 "Esta versão ainda não baixa nem instala mods. Os itens do catálogo são exemplos para testar a interface. A compatibilidade com Terraria Mobile e loaders precisa ser verificada antes de qualquer instalação.");
            Button go = button("Explorar catálogo");
            go.setOnClickListener(v -> showPage("Catálogo"));
            content.addView(go);
        } else if ("Catálogo".equals(page)) {
            showCatalog(false);
        } else {
            showCatalog(true);
        }
    }

    private void showCatalog(boolean favoritesOnly) {
        heading(favoritesOnly ? "Minha biblioteca" : "Catálogo de mods");
        if (!favoritesOnly) {
            EditText search = new EditText(this);
            search.setSingleLine(true);
            search.setHint("Pesquisar mods...");
            search.setTextColor(white);
            search.setHintTextColor(Color.LTGRAY);
            search.setPadding(dp(12), 0, dp(12), 0);
            search.setBackgroundColor(panel);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(48));
            sp.bottomMargin = dp(10);
            content.addView(search, sp);

            LinearLayout categories = new LinearLayout(this);
            categories.setOrientation(LinearLayout.HORIZONTAL);
            String[] cats = {"Todos", "Conteúdo", "Utilidade", "Texturas"};
            for (String cat : cats) {
                Button b = new Button(this);
                b.setText(cat);
                b.setTextSize(10);
                b.setAllCaps(false);
                b.setOnClickListener(v -> {
                    selectedCategory = cat;
                    showPage("Catálogo");
                });
                categories.addView(b, new LinearLayout.LayoutParams(0, dp(44), 1));
            }
            content.addView(categories);
            TextView active = new TextView(this);
            active.setText("Categoria: " + selectedCategory);
            active.setTextColor(cyan);
            active.setTextSize(12);
            active.setPadding(0, dp(6), 0, dp(8));
            content.addView(active);

            search.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                public void onTextChanged(CharSequence s, int st, int before, int count) {
                    searchText = s.toString();
                    renderModCards(false);
                }
                public void afterTextChanged(Editable e) {}
            });
        } else {
            TextView note = new TextView(this);
            note.setText("Seus favoritos salvos neste aparelho.");
            note.setTextColor(Color.LTGRAY);
            note.setTextSize(13);
            note.setPadding(0, 0, 0, dp(10));
            content.addView(note);
        }
        renderModCards(favoritesOnly);
    }

    private void renderModCards(boolean favoritesOnly) {
        // Remove only the result area; preserve the search and category controls.
        int start = favoritesOnly ? 2 : 4;
        while (content.getChildCount() > start) content.removeViewAt(start);
        int count = 0;
        Set<String> saved = prefs.getStringSet("favorites", new HashSet<String>());
        for (String[] mod : mods) {
            boolean favorite = saved.contains(mod[0]);
            if (favoritesOnly && !favorite) continue;
            if (!favoritesOnly && !("Todos".equals(selectedCategory) || selectedCategory.equals(mod[1]))) continue;
            if (!favoritesOnly && !mod[0].toLowerCase().contains(searchText.toLowerCase())) continue;
            addModCard(mod, favorite);
            count++;
        }
        if (count == 0) {
            TextView empty = new TextView(this);
            empty.setText(favoritesOnly ? "Você ainda não salvou favoritos." : "Nenhum item encontrado nessa pesquisa.");
            empty.setTextColor(Color.LTGRAY);
            empty.setPadding(0, dp(12), 0, 0);
            content.addView(empty);
        }
    }

    private void addModCard(String[] mod, boolean favorite) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(10);
        content.addView(box, params);

        TextView name = new TextView(this);
        name.setText(mod[0]);
        name.setTextColor(cyan);
        name.setTextSize(16);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(name);

        TextView meta = new TextView(this);
        meta.setText(mod[1] + "  •  Demonstrativo");
        meta.setTextColor(Color.LTGRAY);
        meta.setTextSize(11);
        box.addView(meta);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button details = button("Detalhes");
        details.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle(mod[0])
            .setMessage(mod[2] + "\n\nStatus: apenas demonstração. Download e instalação não disponíveis.")
            .setPositiveButton("Entendi", (d, w) -> {})
            .show());
        Button save = button(favorite ? "★ Salvo" : "☆ Favoritar");
        save.setOnClickListener(v -> toggleFavorite(mod[0]));
        actions.addView(details, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(46), 1));
        box.addView(actions);
    }

    private void toggleFavorite(String name) {
        Set<String> saved = new HashSet<>(prefs.getStringSet("favorites", new HashSet<String>()));
        if (saved.contains(name)) {
            saved.remove(name);
            Toast.makeText(this, "Removido dos favoritos", Toast.LENGTH_SHORT).show();
        } else {
            saved.add(name);
            Toast.makeText(this, "Adicionado aos favoritos", Toast.LENGTH_SHORT).show();
        }
        prefs.edit().putStringSet("favorites", saved).apply();
        showPage("Catálogo");
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setAllCaps(false);
        return b;
    }

    private void heading(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(white);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(12));
        content.addView(t);
    }

    private void card(String title, String body) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(12);
        content.addView(box, params);
        TextView h = new TextView(this);
        h.setText(title);
        h.setTextColor(cyan);
        h.setTextSize(16);
        h.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(h);
        TextView p = new TextView(this);
        p.setText(body);
        p.setTextColor(white);
        p.setTextSize(14);
        p.setLineSpacing(dp(3), 1f);
        p.setPadding(0, dp(8), 0, 0);
        box.addView(p);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
