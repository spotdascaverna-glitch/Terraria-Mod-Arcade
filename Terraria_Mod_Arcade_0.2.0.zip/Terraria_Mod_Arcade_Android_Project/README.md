# Terraria Mod Arcade — Mods para Terraria

Versão 0.2.0 — protótipo Android nativo em Java.

## Recursos desta versão
- Catálogo demonstrativo com pesquisa por nome.
- Filtros por categoria.
- Janela de detalhes dos itens.
- Favoritos locais persistentes na Biblioteca.
- Interface inicial e navegação entre abas.

## Limitações
Os itens do catálogo são demonstrativos. Esta versão NÃO baixa nem instala mods, não integra Bunny Loader ou outro loader e não garante compatibilidade com Terraria Mobile 1.4.5.8.1. As próximas etapas devem validar fontes e compatibilidade antes de implementar downloads ou instalação.

## Compilar
Use GitHub Actions com JDK 17, Gradle 8.9 e Android SDK API 35.
