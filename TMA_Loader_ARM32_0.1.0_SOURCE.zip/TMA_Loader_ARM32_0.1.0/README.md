# TMA Loader ARM32 0.1.0

Protótipo Android para Redmi 9A / Android 10 / `armeabi-v7a`.

## O que esta versão faz
- Mostra as ABIs informadas pelo próprio Android.
- Importa arquivos escolhidos pelo usuário via Storage Access Framework.
- Copia os arquivos para a biblioteca privada do aplicativo.
- Lista e remove itens da biblioteca.
- Tenta abrir o Terraria instalado pelo identificador Android conhecido.

## O que ainda NÃO faz
- Não carrega/injeta mods dentro do Terraria.
- Não altera o APK, os dados ou os saves do Terraria.
- Não interpreta nem instala pacotes de mods automaticamente.
- Não contém bibliotecas proprietárias do jogo.

## Build
Requer JDK 17, Android SDK 35 e Gradle 8.9:
`gradle assembleDebug`

O APK é Java/Kotlin sem bibliotecas nativas. Em um Android 32-bit, o processo será executado como 32-bit; a tela também informa as ABIs expostas pelo sistema.
