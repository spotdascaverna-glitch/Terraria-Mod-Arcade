package com.spotdascaverna.tmaloader;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 41;
    private LinearLayout libraryList;
    private TextView statusText;
    private final String GAME_PACKAGE = "com.and.games505.TerrariaPaid";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF182313);
        getWindow().setNavigationBarColor(0xFF10170D);
        buildScreen();
        refreshLibrary();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(0xFF10170D);
        scroll.addView(root);

        TextView title = text("TMA LOADER", 27, 0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = text("Terraria Mod Arcade • ARM32 Edition 0.1.0", 13, 0xFFB9CBAE);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.bottomMargin = dp(18);
        root.addView(subtitle, subParams);

        statusText = text("", 14, 0xFFE6F2DD);
        statusText.setPadding(dp(12), dp(12), dp(12), dp(12));
        statusText.setBackgroundColor(0xFF24351C);
        root.addView(statusText);

        root.addView(button("＋  Importar conteúdo", this::pickFile));
        root.addView(button("Abrir Terraria", this::openTerraria));

        TextView note = text("Esta versão é um gerenciador experimental. Ela importa e organiza arquivos na biblioteca privada do TMA; ainda NÃO injeta nem carrega mods dentro do Terraria.", 13, 0xFFFFD18A);
        note.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(note);

        TextView libraryTitle = text("Minha biblioteca", 20, 0xFFFFFFFF);
        libraryTitle.setTypeface(null, 1);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(18);
        lp.bottomMargin = dp(8);
        root.addView(libraryTitle, lp);

        libraryList = new LinearLayout(this);
        libraryList.setOrientation(LinearLayout.VERTICAL);
        root.addView(libraryList);

        TextView footer = text("Compatibilidade detectada pelo sistema • Sem root • Sem modificar o APK do jogo", 11, 0xFF91A486);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(22);
        root.addView(footer, fp);

        setContentView(scroll);
        updateDeviceStatus();
    }

    private void updateDeviceStatus() {
        String[] abis = Build.SUPPORTED_ABIS;
        String abiText = (abis == null || abis.length == 0) ? "não informada" : join(abis);
        String bitness = (Build.SUPPORTED_64_BIT_ABIS != null && Build.SUPPORTED_64_BIT_ABIS.length > 0)
                ? "64 bits disponível" : "somente 32 bits";
        statusText.setText("DISPOSITIVO\n" + Build.MANUFACTURER + " " + Build.MODEL
                + "\nAndroid " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nABIs: " + abiText + "\nSistema: " + bitness);
    }

    private String join(String[] values) {
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(", ");
            out.append(value);
        }
        return out.toString();
    }

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            importFile(data.getData());
        }
    }

    private void importFile(Uri uri) {
        try {
            String name = "conteudo_" + System.currentTimeMillis() + ".bin";
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new Exception("Não foi possível abrir o arquivo.");
                File dir = new File(getFilesDir(), "library");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Não foi possível criar a biblioteca.");
                File outFile = new File(dir, name);
                try (FileOutputStream out = new FileOutputStream(outFile)) {
                    byte[] buffer = new byte[8192];
                    int read;
                    long total = 0;
                    while ((read = in.read(buffer)) != -1) {
                        total += read;
                        if (total > 200L * 1024L * 1024L) {
                            out.close();
                            outFile.delete();
                            throw new Exception("Arquivo maior que o limite de 200 MB.");
                        }
                        out.write(buffer, 0, read);
                    }
                }
            }
            Toast.makeText(this, "Arquivo importado para a biblioteca do TMA.", Toast.LENGTH_LONG).show();
            refreshLibrary();
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao importar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openTerraria() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(GAME_PACKAGE);
        if (launch == null) {
            Toast.makeText(this, "Terraria não encontrado com o identificador esperado.", Toast.LENGTH_LONG).show();
            return;
        }
        try { startActivity(launch); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível abrir o Terraria.", Toast.LENGTH_LONG).show(); }
    }

    private void refreshLibrary() {
        if (libraryList == null) return;
        libraryList.removeAllViews();
        File dir = new File(getFilesDir(), "library");
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            TextView empty = text("Sua biblioteca está vazia. Importe um arquivo para começar.", 14, 0xFFB9CBAE);
            empty.setPadding(dp(8), dp(12), dp(8), dp(12));
            libraryList.addView(empty);
            return;
        }
        for (File file : files) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackgroundColor(0xFF1C2916);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
            rowParams.bottomMargin = dp(8);
            TextView filename = text(file.getName(), 14, 0xFFFFFFFF);
            row.addView(filename);
            TextView size = text(String.format(Locale.getDefault(), "%.1f KB", file.length() / 1024.0), 11, 0xFFB9CBAE);
            row.addView(size);
            row.addView(button("Remover da biblioteca", () -> {
                if (file.delete()) {
                    Toast.makeText(this, "Arquivo removido.", Toast.LENGTH_SHORT).show();
                    refreshLibrary();
                } else Toast.makeText(this, "Não foi possível remover o arquivo.", Toast.LENGTH_SHORT).show();
            }));
            libraryList.addView(row, rowParams);
        }
    }
}
