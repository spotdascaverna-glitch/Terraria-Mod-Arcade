package com.terrariamodarcade;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout content;
    private int cyan = Color.rgb(83, 220, 220);
    private int background = Color.rgb(13, 18, 31);
    private int panel = Color.rgb(27, 36, 55);
    private int white = Color.rgb(239, 245, 255);

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background);
        root.setPadding(dp(18), dp(18), dp(18), dp(12));

        TextView title = new TextView(this);
        title.setText("TERRARIA MOD ARCADE");
        title.setTextColor(cyan);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Mods para Terraria  •  Versão inicial 0.1.0");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(14));
        root.addView(subtitle);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Início", "Catálogo", "Biblioteca"};
        for (String name : names) {
            Button b = new Button(this);
            b.setText(name);
            b.setTextSize(11);
            b.setAllCaps(false);
            b.setOnClickListener(v -> showPage(name));
            tabs.addView(b, new LinearLayout.LayoutParams(0, dp(48), 1));
        }
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(12), 0, dp(8));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        showPage("Início");
    }

    private void showPage(String page) {
        content.removeAllViews();
        if ("Início".equals(page)) {
            heading("Bem-vindo ao Arcade!");
            card("Seu espaço para organizar mods de Terraria.",
                 "Esta é a primeira estrutura do aplicativo. O catálogo atual é demonstrativo: nenhum mod é baixado ou instalado nesta versão.");
            card("Compatibilidade",
                 "Alvo planejado: Terraria Mobile 1.4.5.8.1. A compatibilidade com loaders e instalação automática ainda precisa ser verificada.");
            card("Próximo passo",
                 "Adicionar fontes confiáveis, validar arquivos e testar um método de instalação compatível com Android.");
        } else if ("Catálogo".equals(page)) {
            heading("Catálogo");
            card("Catálogo de demonstração",
                 "Os itens reais ainda serão adicionados depois que confirmarmos fontes e compatibilidade. Não há downloads ativos nesta versão.");
        } else {
            heading("Minha biblioteca");
            card("Nenhum mod instalado",
                 "Quando houver suporte de instalação confirmado, esta área poderá listar os mods que você importar ou instalar.");
        }
    }

    private void heading(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(white);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(12));
        content.addView(t);
    }

    private void card(String title, String body) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(12);
        content.addView(box, params);

        TextView h = new TextView(this);
        h.setText(title);
        h.setTextColor(cyan);
        h.setTextSize(16);
        h.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(h);

        TextView p = new TextView(this);
        p.setText(body);
        p.setTextColor(white);
        p.setTextSize(14);
        p.setLineSpacing(dp(3), 1f);
        p.setPadding(0, dp(8), 0, 0);
        box.addView(p);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
