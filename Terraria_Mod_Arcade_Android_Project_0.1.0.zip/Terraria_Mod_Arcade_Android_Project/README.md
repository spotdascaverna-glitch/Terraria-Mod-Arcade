# Terraria Mod Arcade — Mods para Terraria

Projeto Android nativo inicial (versão 0.1.0).

## O que existe nesta primeira estrutura
- Aplicativo Android nativo em Java.
- Tela inicial, catálogo demonstrativo e biblioteca.
- Workflow do GitHub Actions para compilar um APK de teste.

## O que ainda NÃO existe
- Downloads reais de mods.
- Instalação automática.
- Integração com Bunny Loader ou outro loader.
- Garantia de compatibilidade com Terraria Mobile 1.4.5.8.1.

Essas funções só devem ser implementadas depois de verificar a compatibilidade técnica e as fontes de mods.

## Como compilar
O workflow `.github/workflows/build-apk.yml` compila o projeto no GitHub Actions quando houver um push para `main` ou quando for iniciado manualmente. O APK de teste aparece em **Actions > Build Android APK > Artifacts**.

Requisitos de compilação: JDK 17, Gradle 8.9 e Android SDK com API 35.
