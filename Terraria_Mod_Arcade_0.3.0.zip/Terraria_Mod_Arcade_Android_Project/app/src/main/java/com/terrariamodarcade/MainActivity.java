package com.terrariamodarcade;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.*;
import android.text.TextWatcher;
import android.text.Editable;
import android.app.AlertDialog;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout content;
    private final int cyan = Color.rgb(83, 220, 220);
    private final int background = Color.rgb(13, 18, 31);
    private final int panel = Color.rgb(27, 36, 55);
    private final int white = Color.rgb(239, 245, 255);
    private SharedPreferences prefs;
    private String selectedCategory = "Todos";
    private String searchText = "";

    // Nome, categoria, descrição, compatibilidade, status, fonte
    private final String[][] mods = {
        {"Bunny Loader", "Ferramenta",
         "Projeto comunitário de carregador de mods para Terraria no Android. É uma ferramenta separada; não é um mod.",
         "Android • projeto comunitário. A compatibilidade exata com sua versão do Terraria deve ser conferida na documentação.",
         "Ferramenta comunitária • verificar versão", "https://github.com/JonataOliveiraa/Bunny-Loader"},
        {"Calamity Mod", "Conteúdo",
         "Grande expansão de conteúdo, chefes e equipamentos. Este é um mod conhecido do ecossistema de PC.",
         "PC • tModLoader. Não marcado como compatível com Terraria Mobile.",
         "PC • não compatível diretamente com Mobile", "https://terraria.wiki.gg/wiki/Calamity_Mod"},
        {"Thorium Mod", "Conteúdo",
         "Expansão conhecida com novas classes e conteúdo para Terraria no ecossistema de PC.",
         "PC • tModLoader. Não marcado como compatível com Terraria Mobile.",
         "PC • não compatível diretamente com Mobile", "https://terraria.wiki.gg/wiki/Thorium_Mod"},
        {"Recipe Browser", "Utilidade",
         "Ferramenta para consultar receitas dentro do jogo no ecossistema de mods para PC.",
         "PC • tModLoader. Não marcado como compatível com Terraria Mobile.",
         "PC • não compatível diretamente com Mobile", "https://github.com/tModLoader/tModLoader"},
        {"Boss Checklist", "Utilidade",
         "Ajuda a acompanhar a progressão de chefes no ecossistema de mods para PC.",
         "PC • tModLoader. Não marcado como compatível com Terraria Mobile.",
         "PC • não compatível diretamente com Mobile", "https://github.com/tModLoader/tModLoader"},
        {"Pacote de texturas", "Texturas",
         "Pacotes visuais dependem do formato do arquivo e da ferramenta que os carrega. Nenhum pacote está incluído aqui.",
         "Compatibilidade não verificada para Terraria Mobile 1.4.5.8.1.",
         "Compatibilidade não verificada", "https://github.com/JonataOliveiraa/Bunny-Loader"}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("arcade_library", MODE_PRIVATE);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        buildShell();
        showPage("Início");
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background);
        root.setPadding(dp(16), dp(16), dp(16), dp(10));

        TextView title = new TextView(this);
        title.setText("TERRARIA MOD ARCADE");
        title.setTextColor(cyan); title.setTextSize(21);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Mods para Terraria  •  Versão 0.3.0");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        root.addView(subtitle);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Início", "Catálogo", "Biblioteca", "Compatibilidade"};
        for (String name : names) {
            Button b = new Button(this);
            b.setText(name); b.setTextSize(9); b.setAllCaps(false);
            b.setOnClickListener(v -> showPage(name));
            tabs.addView(b, new LinearLayout.LayoutParams(0, dp(48), 1));
        }
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(10), 0, dp(8));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void showPage(String page) {
        content.removeAllViews();
        if ("Início".equals(page)) {
            heading("Bem-vindo ao Arcade!");
            card("Catálogo mais informativo",
                "Veja a plataforma de cada projeto, seu status de compatibilidade e a fonte de referência.");
            card("Biblioteca pessoal",
                "Seus favoritos continuam salvos neste aparelho, mesmo depois de fechar o aplicativo.");
            card("Importante",
                "O Terraria Mod Arcade ainda não baixa, instala nem executa mods. Os links abrem páginas de referência; confira sempre a versão e a segurança antes de usar qualquer arquivo.");
            Button go = button("Explorar catálogo");
            go.setOnClickListener(v -> showPage("Catálogo"));
            content.addView(go);
        } else if ("Catálogo".equals(page)) {
            showCatalog(false);
        } else if ("Biblioteca".equals(page)) {
            showCatalog(true);
        } else {
            showCompatibility();
        }
    }

    private void showCompatibility() {
        heading("Compatibilidade");
        card("Terraria Mobile 1.4.5.8.1",
            "O suporte oficial a mods no Terraria Mobile não é fornecido pela Re-Logic. Existem projetos comunitários para Android, mas cada ferramenta e cada mod precisam ser conferidos separadamente.");
        card("Mods de PC",
            "Calamity, Thorium, Recipe Browser e Boss Checklist são apresentados aqui como referências do ecossistema tModLoader para PC. Não os considere instaláveis diretamente no Terraria Mobile.");
        card("Projetos comunitários",
            "Bunny Loader é um projeto comunitário para Terraria no Android. A página do projeto contém documentação e instruções atualizadas. Este aplicativo não substitui o loader e não confirma compatibilidade automática com toda versão do jogo.");
        Button source = button("Abrir página do Bunny Loader");
        source.setOnClickListener(v -> openUrl("https://github.com/JonataOliveiraa/Bunny-Loader"));
        content.addView(source);
        TextView note = new TextView(this);
        note.setText("Regra do Arcade: só exibiremos um item como compatível quando houver uma fonte que confirme a versão.");
        note.setTextColor(cyan); note.setTextSize(13);
        note.setPadding(0, dp(12), 0, 0);
        content.addView(note);
    }

    private void showCatalog(boolean favoritesOnly) {
        heading(favoritesOnly ? "Minha biblioteca" : "Catálogo");
        if (!favoritesOnly) {
            EditText search = new EditText(this);
            search.setSingleLine(true); search.setHint("Pesquisar mods e ferramentas...");
            search.setTextColor(white); search.setHintTextColor(Color.LTGRAY);
            search.setPadding(dp(12), 0, dp(12), 0); search.setBackgroundColor(panel);
            content.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));

            LinearLayout categories = new LinearLayout(this);
            categories.setOrientation(LinearLayout.HORIZONTAL);
            String[] cats = {"Todos", "Conteúdo", "Utilidade", "Texturas", "Ferramenta"};
            for (String cat : cats) {
                Button b = button(cat); b.setTextSize(9);
                b.setOnClickListener(v -> { selectedCategory = cat; showPage("Catálogo"); });
                categories.addView(b, new LinearLayout.LayoutParams(0, dp(44), 1));
            }
            content.addView(categories);
            TextView active = new TextView(this);
            active.setText("Categoria: " + selectedCategory);
            active.setTextColor(cyan); active.setTextSize(12);
            active.setPadding(0, dp(6), 0, dp(8));
            content.addView(active);
            search.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
                public void onTextChanged(CharSequence s,int st,int before,int count) {
                    searchText=s.toString(); renderModCards(false);
                }
                public void afterTextChanged(Editable e) {}
            });
        } else {
            TextView note = new TextView(this);
            note.setText("Itens que você favoritou neste aparelho.");
            note.setTextColor(Color.LTGRAY); note.setTextSize(13);
            note.setPadding(0, 0, 0, dp(10)); content.addView(note);
        }
        renderModCards(favoritesOnly);
    }

    private void renderModCards(boolean favoritesOnly) {
        int start = favoritesOnly ? 2 : 4;
        while (content.getChildCount() > start) content.removeViewAt(start);
        int count=0;
        Set<String> saved = prefs.getStringSet("favorites", new HashSet<String>());
        for (String[] item : mods) {
            boolean favorite=saved.contains(item[0]);
            if (favoritesOnly && !favorite) continue;
            if (!favoritesOnly && !("Todos".equals(selectedCategory) || selectedCategory.equals(item[1]))) continue;
            String haystack=(item[0]+" "+item[1]+" "+item[4]).toLowerCase();
            if (!favoritesOnly && !haystack.contains(searchText.toLowerCase())) continue;
            addModCard(item,favorite); count++;
        }
        if (count==0) {
            TextView empty=new TextView(this);
            empty.setText(favoritesOnly ? "Você ainda não salvou favoritos." : "Nenhum item encontrado.");
            empty.setTextColor(Color.LTGRAY); empty.setPadding(0,dp(12),0,0);
            content.addView(empty);
        }
    }

    private void addModCard(String[] item, boolean favorite) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setBackgroundColor(panel);
        box.setPadding(dp(13),dp(11),dp(13),dp(10));
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);
        params.bottomMargin=dp(10); content.addView(box,params);

        TextView name=new TextView(this);
        name.setText(item[0]); name.setTextColor(cyan); name.setTextSize(16);
        name.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(name);
        TextView meta=new TextView(this);
        meta.setText(item[1]+"  •  "+item[4]); meta.setTextColor(Color.LTGRAY);
        meta.setTextSize(11); meta.setPadding(0,dp(3),0,dp(5)); box.addView(meta);

        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button details=button("Detalhes");
        details.setOnClickListener(v -> showDetails(item));
        Button save=button(favorite ? "★ Salvo" : "☆ Favoritar");
        save.setOnClickListener(v -> toggleFavorite(item[0]));
        actions.addView(details,new LinearLayout.LayoutParams(0,dp(44),1));
        actions.addView(save,new LinearLayout.LayoutParams(0,dp(44),1));
        box.addView(actions);
    }

    private void showDetails(String[] item) {
        new AlertDialog.Builder(this)
            .setTitle(item[0])
            .setMessage(item[2]+"\n\nCompatibilidade:\n"+item[3]+"\n\nStatus:\n"+item[4])
            .setNeutralButton("Abrir fonte",(d,w)->openUrl(item[5]))
            .setPositiveButton("Fechar",(d,w)->{})
            .show();
    }

    private void toggleFavorite(String name) {
        Set<String> saved=new HashSet<>(prefs.getStringSet("favorites",new HashSet<String>()));
        if(saved.contains(name)) {
            saved.remove(name);
            Toast.makeText(this,"Removido dos favoritos",Toast.LENGTH_SHORT).show();
        } else {
            saved.add(name);
            Toast.makeText(this,"Adicionado à Biblioteca",Toast.LENGTH_SHORT).show();
        }
        prefs.edit().putStringSet("favorites",saved).apply();
        showPage("Catálogo");
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception e) { Toast.makeText(this,"Não foi possível abrir o link.",Toast.LENGTH_SHORT).show(); }
    }

    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextSize(11);
        b.setAllCaps(false); return b;
    }
    private void heading(String text) {
        TextView t=new TextView(this); t.setText(text); t.setTextColor(white);
        t.setTextSize(20); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setPadding(0,dp(8),0,dp(12)); content.addView(t);
    }
    private void card(String title,String body) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel); box.setPadding(dp(15),dp(13),dp(15),dp(13));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin=dp(11); content.addView(box,p);
        TextView h=new TextView(this); h.setText(title); h.setTextColor(cyan);
        h.setTextSize(16); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(h);
        TextView b=new TextView(this); b.setText(body); b.setTextColor(white);
        b.setTextSize(13); b.setLineSpacing(dp(3),1f); b.setPadding(0,dp(7),0,0);
        box.addView(b);
    }
    private int dp(int value) {
        return (int)(value*getResources().getDisplayMetrics().density+0.5f);
    }
}
