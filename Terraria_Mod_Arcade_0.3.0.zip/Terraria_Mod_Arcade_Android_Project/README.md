# Terraria Mod Arcade — Mods para Terraria

Versão 0.3.0 — protótipo Android nativo em Java.

## Novidades da versão 0.3.0
- Aba de compatibilidade com informações gerais sobre Terraria Mobile.
- Catálogo com classificação de plataforma e status de compatibilidade.
- Detalhes dos itens com botão para abrir a fonte de referência.
- Pesquisa por nome, categoria e status.
- Categoria Ferramenta para projetos de loader.
- Favoritos locais preservados na Biblioteca.

## Limitações importantes
- O aplicativo ainda NÃO baixa, instala ou executa mods.
- Os links abrem páginas externas de referência.
- A compatibilidade de cada ferramenta e mod deve ser verificada para a versão exata do Terraria.
- Calamity, Thorium, Recipe Browser e Boss Checklist são referências do ecossistema de PC/tModLoader, não mods instaláveis diretamente no Terraria Mobile.
- Bunny Loader é um projeto comunitário independente. O Arcade não é afiliado a ele e não confirma compatibilidade automática.

## Compilar
Use GitHub Actions com JDK 17, Gradle 8.9 e Android SDK API 35.
