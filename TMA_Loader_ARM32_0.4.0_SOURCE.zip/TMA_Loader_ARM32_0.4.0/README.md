# TMA Loader Android 0.4.0

Aplicativo Android nativo em Java, sem bibliotecas externas. Esta versão adiciona três áreas de catálogo (Mods, Texturas e Mapas), biblioteca separada por categoria e importação local de arquivos.

## O que funciona
- Catálogo informativo com avisos de compatibilidade.
- Importação e organização local de arquivos nas categorias Mods, Texturas e Mapas.
- Validação de extensão para mundos `.wld`.
- Para mundos `.wld`, tentativa de cópia para `Android/data/com.and.games505.TerrariaPaid/Worlds` em Android 10, mediante permissão de armazenamento.
- Diagnóstico do Android e ABIs.

## Limites importantes
- A 505 Games informa que mods e pacotes de textura não são suportados oficialmente nas plataformas móveis: https://support.505games.com/support/solutions/articles/150000146904-can-we-get-mods-or-texture-packs-
- Por isso, os itens de Mods e Texturas são informativos/armazenamento local; o TMA não instala nem executa esses conteúdos no jogo.
- Mapas: o TMA aceita arquivos `.wld` e tenta copiá-los para a pasta Worlds conhecida do Terraria Android. A disponibilidade dessa pasta e as permissões dependem do dispositivo/versão do jogo. Feche o Terraria antes de copiar e mantenha backup dos mundos. A cópia não garante que um mundo de outra versão seja compatível.
- Nenhum arquivo é executado pelo TMA nem enviado à internet.

## Compatibilidade do app
- Android 6.0+ (minSdk 23).
- `targetSdk 28`; projetado para o dispositivo Android 10 do projeto.
- Java sem bibliotecas nativas, portanto não depende de ABI nativa ARM64.
- `versionCode 4`, `versionName 0.4.0`.

## Build
Execute `gradle assembleDebug` na raiz. Saída: `app/build/outputs/apk/debug/app-debug.apk`.
