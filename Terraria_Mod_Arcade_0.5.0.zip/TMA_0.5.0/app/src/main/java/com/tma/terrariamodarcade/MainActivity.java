package com.tma.terrariamodarcade;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_CONTENT = 51;
    private LinearLayout contentList;
    private TextView importedInfo;
    private SharedPreferences prefs;
    private int blue = Color.rgb(31, 69, 112);
    private int panel = Color.rgb(25, 39, 60);
    private int cyan = Color.rgb(112, 217, 255);
    private int white = Color.rgb(239, 246, 255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("tma_library", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(11,20,36));
        getWindow().setNavigationBarColor(Color.rgb(11,20,36));
        buildScreen();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void buildScreen() {
        LinearLayout root = column();
        root.setBackgroundColor(Color.rgb(11,20,36));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = column();
        page.setPadding(dp(18), dp(20), dp(18), dp(28));

        LinearLayout hero = column();
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(shape(blue, dp(18)));
        TextView logo = text("TMA", 34, Color.WHITE, true);
        logo.setLetterSpacing(0.12f);
        hero.addView(logo);
        TextView full = text("TERRARIA MOD ARCADE  •  v0.5.0", 11, cyan, true);
        full.setPadding(0, dp(2), 0, dp(10));
        hero.addView(full);
        hero.addView(text("Seu espaço para explorar conteúdo de Terraria Mobile.", 15, white, false));
        page.addView(hero);

        addSection(page, "Biblioteca", "Conteúdo organizado por categoria.");
        contentList = column();
        page.addView(contentList);
        addCatalogCard("🧩  Mods", "Projetos e ferramentas para Terraria Mobile. Compatibilidade precisa ser confirmada.");
        addCatalogCard("🎨  Texturas", "Pacotes visuais. A importação não significa instalação automática.");
        addCatalogCard("🗺️  Mapas", "Mundos e arquivos de mapa para análise e organização.");

        Button add = button("＋  ADICIONAR CONTEÚDO", cyan, Color.rgb(8,25,42));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(16);
        page.addView(add, bp);
        add.setOnClickListener(v -> chooseContent());

        importedInfo = text("", 13, cyan, false);
        importedInfo.setPadding(dp(4), dp(12), dp(4), dp(4));
        page.addView(importedInfo);
        String last = prefs.getString("last_import", "");
        if (!last.isEmpty()) importedInfo.setText("Último arquivo selecionado: " + last +
                "\nGuardado como referência na biblioteca do TMA — ainda não instalado no Terraria.");

        addSection(page, "Integração experimental", "Uma interface sobre o jogo e uma integração real são coisas diferentes.");
        LinearLayout experiment = column();
        experiment.setPadding(dp(16), dp(15), dp(16), dp(15));
        experiment.setBackground(shape(panel, dp(14)));
        experiment.addView(text("🛠️  Painel TMA para Terraria", 17, white, true));
        TextView note = text("Esta versão prepara a área experimental. Ainda não existe um carregador confirmado para controlar sua versão do Terraria Mobile (1.4.5.8.1). O painel não altera o jogo por enquanto.", 13, Color.rgb(190,205,222), false);
        note.setPadding(0, dp(8), 0, dp(12));
        experiment.addView(note);
        Button details = button("VER COMO FUNCIONA", Color.rgb(52,79,111), Color.WHITE);
        experiment.addView(details);
        details.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Integração experimental")
                .setMessage("O TMA ainda não modifica o funcionamento interno do Terraria. Um botão flutuante sozinho só desenha uma interface por cima; para controlar o jogo é necessário um carregador compatível e testado. Não vamos marcar essa função como pronta antes de existir suporte real.")
                .setPositiveButton("Entendi", null).show());
        page.addView(experiment);

        TextView footer = text("TMA • Feito para Terraria Mobile\nUse somente arquivos de fontes confiáveis e compatíveis.", 11, Color.rgb(135,157,181), false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(24), 0, 0);
        page.addView(footer);

        scroll.addView(page);
        root.addView(scroll);
        setContentView(root);
    }

    private void addSection(LinearLayout parent, String title, String subtitle) {
        TextView h = text(title, 21, white, true);
        h.setPadding(dp(2), dp(22), 0, dp(4));
        parent.addView(h);
        TextView s = text(subtitle, 12, Color.rgb(157,178,201), false);
        s.setPadding(dp(2), 0, 0, dp(10));
        parent.addView(s);
    }

    private void addCatalogCard(String title, String desc) {
        LinearLayout card = column();
        card.setPadding(dp(15), dp(13), dp(15), dp(13));
        card.setBackground(shape(panel, dp(13)));
        TextView h = text(title, 16, white, true);
        card.addView(h);
        TextView d = text(desc, 12, Color.rgb(184,200,218), false);
        d.setPadding(0, dp(5), 0, 0);
        card.addView(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9);
        contentList.addView(card, lp);
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(shape(bg, dp(13)));
        return b;
    }

    private void chooseContent() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, PICK_CONTENT);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_CONTENT || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = uri.getLastPathSegment();
        if (name == null || name.trim().isEmpty()) name = "Arquivo selecionado";
        String lower = name.toLowerCase(Locale.ROOT);
        String category = lower.endsWith(".wld") || lower.endsWith(".twld") ? "Mapa"
                : lower.endsWith(".png") || lower.endsWith(".zip") ? "Textura ou pacote"
                : lower.endsWith(".tmod") ? "Mod (formato pode não ser compatível com Mobile)"
                : "Arquivo para verificar";
        prefs.edit().putString("last_import", name).apply();
        if (importedInfo != null) importedInfo.setText("Selecionado: " + name + "\nCategoria provável: " + category +
                "\nAdicionado à lista de referência do TMA. O arquivo não foi instalado nem executado no Terraria.");
        new AlertDialog.Builder(this)
                .setTitle("Arquivo selecionado")
                .setMessage(name + "\n\n" + category + "\n\nO TMA registrou a seleção, mas ainda não instala esse arquivo no Terraria. A compatibilidade deve ser verificada antes de usar.")
                .setPositiveButton("OK", null).show();
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
